# Tick-mon
The repository for the new tick-tracking app developed by Adam Cantor and Jonah Silverman for the Biology Dept. of Muhlenberg College.
