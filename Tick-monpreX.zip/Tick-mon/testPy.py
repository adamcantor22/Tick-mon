# -*- coding: utf-8 -*-
"""
Created on Mon May 25 14:31:03 2020

@author: AdamPC
"""

#Tries to determine if an input is greater than a constant

def main():
    const = 8
    i = int(input("enter a number: "))
    print(i  > const)
    
    
    
main()
