## 0.1.1+2

* Update setup instructions in the README.

## 0.1.1+1

* Add an android/ folder with no-op implementation to workaround https://github.com/flutter/flutter/issues/46898

## 0.1.1

* Require Flutter SDK 1.12.13+hotfix.4 or greater.
* Fix homepage.

## 0.1.0+3

* Remove the deprecated `author:` field from pubspec.yaml
* Bump the minimum Flutter version to 1.10.0.

## 0.1.0+2

* Add documentation for initializing the default app.

## 0.1.0+1

* Use `package:firebase` for firebase functionality.

## 0.1.0

* Initial open-source release.
