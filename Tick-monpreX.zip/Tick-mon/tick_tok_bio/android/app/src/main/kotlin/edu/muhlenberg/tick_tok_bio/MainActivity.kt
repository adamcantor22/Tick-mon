package edu.muhlenberg.tick_tok_bio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
